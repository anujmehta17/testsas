import { ISiteNavigationWebpartProps } from "./components/ISiteNavigationWebpartProps";
declare const Navigation: (props: ISiteNavigationWebpartProps) => JSX.Element;
export default Navigation;
//# sourceMappingURL=Navigation.d.ts.map