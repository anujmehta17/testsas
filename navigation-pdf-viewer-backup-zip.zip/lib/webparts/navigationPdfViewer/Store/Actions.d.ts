export declare function linkclicked(index: any, url: any): {
    type: string;
    payload: {
        index: any;
        url: any;
    };
};
//# sourceMappingURL=Actions.d.ts.map