declare const Reducer: (state: {
    modal: boolean;
    linkclicked: boolean;
    url: string;
}, action: any) => {
    modal: boolean;
    linkclicked: boolean;
    url: string;
};
export default Reducer;
//# sourceMappingURL=Reducers.d.ts.map