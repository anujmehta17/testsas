declare const styles: {
    table: string;
    haslink: string;
    column: string;
    valuecolumn: string;
};
export default styles;
//# sourceMappingURL=DocumentDisplay.module.scss.d.ts.map