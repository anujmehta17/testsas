declare const DocumentDisplay: (props: {
    ctx;
    url;
}) => JSX.Element;
export default DocumentDisplay;
//# sourceMappingURL=DocumentsDisplay.d.ts.map