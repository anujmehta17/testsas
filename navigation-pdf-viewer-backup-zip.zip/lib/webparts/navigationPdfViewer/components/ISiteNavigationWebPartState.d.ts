import siteProperties from "./siteProperties";
export interface ISiteNavigationWebPartState {
    pageproperty: siteProperties;
    pagesproperty: any;
    url: string;
}
//# sourceMappingURL=ISiteNavigationWebPartState.d.ts.map