import { PageContext } from "@microsoft/sp-page-context";
import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface ISiteNavigationWebpartProps {
    pagectx: PageContext;
    ctx: WebPartContext;
    description: string;
}
//# sourceMappingURL=ISiteNavigationWebpartProps.d.ts.map