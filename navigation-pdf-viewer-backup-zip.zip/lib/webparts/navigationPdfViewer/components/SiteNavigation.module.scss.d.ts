declare const styles: {};
export default styles;
//# sourceMappingURL=SiteNavigation.module.scss.d.ts.map