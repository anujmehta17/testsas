import * as React from 'react';
import { ISiteNavigationWebpartProps } from './ISiteNavigationWebpartProps';
import { ISiteNavigationWebPartState } from './ISiteNavigationWebPartState';
export default class SiteNavigationWebpart extends React.Component<ISiteNavigationWebpartProps, ISiteNavigationWebPartState> {
    constructor(props: ISiteNavigationWebpartProps);
    componentDidMount(): Promise<void>;
    render(): JSX.Element;
}
//# sourceMappingURL=SiteNavigationWebpart.d.ts.map