declare const SitesDisplay: (props: {
    list;
    ctx;
}) => JSX.Element;
export default SitesDisplay;
//# sourceMappingURL=SitesDisplay.d.ts.map