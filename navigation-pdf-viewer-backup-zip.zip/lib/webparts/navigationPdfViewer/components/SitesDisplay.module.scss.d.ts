declare const styles: {
    showdiv: string;
    showdocument: string;
    displayframe: string;
    link: string;
    linksdiv: string;
};
export default styles;
//# sourceMappingURL=SitesDisplay.module.scss.d.ts.map