export default interface siteProperties {
    Title: string;
    Url: string;
}
//# sourceMappingURL=siteProperties.d.ts.map