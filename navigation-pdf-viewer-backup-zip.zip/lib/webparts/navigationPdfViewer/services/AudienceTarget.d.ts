import "@pnp/sp/search";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/items/get-all";
export declare const AudienceTarget: (weburl: any, listname: any, context: any) => Promise<import("@pnp/sp/search").ISearchResult[]>;
//# sourceMappingURL=AudienceTarget.d.ts.map