import "@pnp/sp/search";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/items/get-all";
export declare const DocumentsAudienceTarget: (weburl: any, listname: any, context: any, res: any) => Promise<any>;
//# sourceMappingURL=DocumentsAudienceTarget.d.ts.map