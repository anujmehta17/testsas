/* tslint:disable */
require("./DocumentDisplay.module.css");
const styles = {
  table: 'table_8ce47fae',
  haslink: 'haslink_8ce47fae',
  column: 'column_8ce47fae',
  valuecolumn: 'valuecolumn_8ce47fae'
};

export default styles;
/* tslint:enable */