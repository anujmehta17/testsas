/* tslint:disable */
require("./SiteNavigationWebpart.module.css");
const styles = {
  siteNavigationWebpart: 'siteNavigationWebpart_35e89686',
  container: 'container_35e89686',
  row: 'row_35e89686',
  column: 'column_35e89686',
  'ms-Grid': 'ms-Grid_35e89686',
  title: 'title_35e89686',
  subTitle: 'subTitle_35e89686',
  description: 'description_35e89686',
  button: 'button_35e89686',
  label: 'label_35e89686'
};

export default styles;
/* tslint:enable */