/* tslint:disable */
require("./SitesDisplay.module.css");
const styles = {
  showdiv: 'showdiv_7e691525',
  showdocument: 'showdocument_7e691525',
  displayframe: 'displayframe_7e691525',
  link: 'link_7e691525',
  linksdiv: 'linksdiv_7e691525'
};

export default styles;
/* tslint:enable */