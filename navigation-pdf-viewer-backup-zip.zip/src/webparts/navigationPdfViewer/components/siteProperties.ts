export default interface siteProperties
{
    Title:string,
    Url: string,
    
}