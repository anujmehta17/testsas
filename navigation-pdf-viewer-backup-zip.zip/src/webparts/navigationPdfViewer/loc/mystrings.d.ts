declare interface INavigationPdfViewerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'NavigationPdfViewerWebPartStrings' {
  const strings: INavigationPdfViewerWebPartStrings;
  export = strings;
}
